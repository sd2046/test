'use strict';

(function() {

	// Raven javascript debugger
    if ( PinSaver.raven_enabled && window['Raven'] ) {
        try {
            window['Raven'].config(
                'https://5aaccd05cdc0483b8bda9a8d51eaa973@sentry.io/1218475',
                {
                    release: '1121',
                    environment: 'production',
                    // environment: 'development',
                    ignoreErrors: [
                        /ResizeObserver/
                    ]
                }
            ).install();
        } catch (e) {
        }
    }

    PinSaver.Raven.init(function () {

	const PinDown = {
		id: chrome.runtime.id,
		full: '',
		sitename: '',
		url: '',

		pinNum: null,
		collection: {
			id: [],
			links: []
		},

		button: null,
		block: null,
		imageBlock: null,
		loaderBlock: null,
		saveFolder: {},
		runButton: {},
		loaderJS: null,
		inProgress: false,
		savedItems: 0,

        stopped: false,
        finished: false,
        paused: false,
        isLoaded: false,

		title: '',
		inProgressChar: '▶',
		folderPrefix: 'PinDown__',
        showPinButton: true,
		policyAgree: false,

		currentBoardName: null,
        currentPins: [],
        initialData: {},
        prepareDataReady: Promise.resolve(),
        prepareDataEveryTime: false,

		CORSBGResolver: {},

		//--------- INIT ---------

		init: function() {
            this.sitename = window.location.hostname;
            this.fetch = this.fetch.bind(this);

			if ( this.isPinterest ) {
                const initial = document.getElementById('initial-state');

                if ( initial ) {
                    try {
                        this.initialData = JSON.parse(initial.innerText);
                        if (this.initialData !== null && this.initialData.viewer) {
                            PinSaver.Raven.setUserContext({
                                // user boards is available
                                isAuth: this.initialData.viewer.isAuth
                            });
                        }
                    } catch (e) {
                        PinSaver.log('Error parsing initial data!');
                    }
                } else {
                    PinSaver.log('No initial data!');
                }

				this.ready();

			} else if ( this.isInstagram || this.isBehance ) {
                if ( PinSaver.select('.dialog-404') ) {
                    this.hideAction();
                    return;
                }
                this.ready();
                this.prepareDataReady = this.prepareData();

            } else if ( this.isTumblr || this.isHostx ) {
			    if ( location.pathname.match(/rss/) ) {
                    this.hideAction();
			        return;
                }
				this.ready();

            } else {
                this.hideAction();
            }
		},

        ready: function () {
            if ( !document.body ) {
                PinSaver.log('No body!');
            } else {
                document.body.classList.add(this.sitename.replace(/\./gi, '').replace('www', '').replace('com', ''));

                if (this.isPinterest) {
                    document.body.classList.add('pinterest');
                } else if (this.isTumblr) {
                    document.body.classList.add('tumblr');
                }
            }

            this.runAt = 10;
            this.backgroundLister();
            this.stopFreeVersion();

            PinSaver.log("starting at " + this.sitename + ' -' + this.full + '-');
            PinSaver.Raven.setExtraContext({full: this.full});

            let adapter;
            if ( this.isPinterest ) {
                adapter = 'pinterest';
            } else if ( this.isInstagram ) {
                adapter = 'instagram';
            } else if ( this.isTumblr ) {
                adapter = 'tumblr';
            } else if ( this.isBehance ) {
                adapter = 'behance';
            } else if ( this.isHostx ) {
                adapter = 'sx';
            }

            this.addAdapter(adapter);

            return this.resolveOptions()
                .then(this.updateOptions.bind(this))
                .then(this.pinButton.bind(this));
        },

        addAdapter(adapter) {
            Object.assign(this, PinSaver.adapters[adapter]);

            if ( this.prepareData ) {
                this.prepareData = this.prepareData.bind(this);
            }
            if ( this.setData ) {
                this.setData = this.setData.bind(this);
            }

            if ( this.getData ) {
                this.getData = this.getData.bind(this);
            }

            if ( this.fetchData ) {
                this.fetchData = this.fetchData.bind(this);
            }

        },


        //--------- GETTERS ---------

        // https://securitytrails.com/list/ns/ns1.pinterest.com
        get isPinterest() {
            return this.sitename.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?/) && !this.sitename.match('pinpinterest\.com');
        },

        get isInstagram() {
            return this.sitename.match('instagram.com') && !this.sitename.match('scontent-');
        },

        get isTumblr() {
			var src;
            return (
            		this.sitename.match('tumblr.com')
                 && !/(media|vtt?).tumblr.com$/.test(this.sitename)
                 && !/tumblr.com\/rss$/.test(this.sitename)
                )
				|| Array.prototype.filter.call(document.querySelectorAll('script'), function(script) {
					src = script.getAttribute('src');
					return src && src.match('assets.tumblr.com');
				}).length > 0;
        },

        get isHostx() {
            return this.sitename === PinSaver.fromNumbers('119119119046115101120046099111109');
        },

        get isBehance() {
            return this.sitename === 'www.behance.net';
        },
        /**

        get isImagex() {
            return this.sitename === PinSaver.fromNumbers('119119119046105109097103101102097112046099111109');
        },
        */


        //--------- OPTIONS ---------

		resolveOptions() {
			return new Promise(resolve => {
				chrome.storage.local.get(['policyAgree'], result => {
					resolve(result);
				});
			})
		},

        updateOptions(options) {
            Object.keys(options).forEach(option => {
                this[option] = options[option];
            });
        },

		//--------- RESET UI AFTER CHANGE PAGE ---------

		resetUI: function(softReset) {
			this.savedItems = 0;
			this.inProgress = false;
            this.finished = false;

            if ( this.loaderJS && !softReset ) {
                this.currentBoardName = null;
                this.loaderJS.setValue("∞");
            }

			if ( this.loaderJS && this.loaderJS.setProgress ) {
				this.loaderJS.setProgress(0);
			}

			window.onbeforeunload = null;
            this.resetData(softReset);
			this.resetCollection();
            this.switchPinButton(false);

            PinSaver.log('Reset UI');

			var state = PinSaver.byId('pinsaver_fin' + this.full),
				link = PinSaver.byId('pinsaver__getfull'),
				loader = this.loaderBlock;

			if ( state ) {
				state.style.display = 'none';
				state.className = state.className.replace(' pinsaver-visible', '');
			}

			if ( link ) {
                PinSaver.remove(link);
			}

			if ( this.loaderBlock !== null ) {
				loader.className = loader.className.replace('pinsaver-visible', '');
			}
		},

        updateUI(text) {
		    if ( this.imageBlock ) {
                this.imageBlock.innerHTML = '';
            }
            this.saveFolder.value = this.folderPrefix + PinSaver.simplify(text);
            this.updateLoaderVal();
        },


		//--------- BASE DEFINITIONS AND RUN ACTIONS ---------

		pinButton: function() {
			const block = document.createElement('div');
			const bg = document.createElement('div');
            const button = document.createElement('a');

			bg.className = 'pinsaver__static';
			bg.id = 'static_close' + this.full;
			document.body.appendChild(bg);

            button.className = 'pinsaver__button';
            button.innerHTML = '<img src="chrome-extension://'+this.id+'/images/pinsaver-small.png" class="pinsaver__button-img" />';

			block.className = 'pinsaver__block';
			block.id = 'pinsaver_block' + this.full;
			block.innerHTML = '<div class="pinsaver__block-logo">'
								+ '<img src="chrome-extension://'+this.id+'/images/pinsaver-big.png" alt=""/>'
			 				  + '</div>'
							  + '<div class="pinsaver__block-textReady">'
								+ '<img src="chrome-extension://'+this.id+'/images/pinsaver-ready-free.png" alt=""/>'
							  + '</div>'
							  + '<div class="pinsaver__block-textFolder">'
                                    + '<img src="chrome-extension://'+this.id+'/images/text-folder.png" alt=""/>'
                                    + '<input type="text" class="pinsaver__block-folder" id="pinsaver_folder'+this.full+'">'
                                  + '</div>'
                                  + '<a  class="pinsaver__block-button" id="pinsaver_run'+this.full+'">'
                                    + '<img src="chrome-extension://'+this.id+'/images/button.png" alt=""/>'
                                  + '</a>'
                                  + '<div class="pinsaver__block-process" id="pinsaver_process'+this.full+'">'
                                    + '<a class="pinsaver__block-process-pause pinsaver__block-process-button pinsaver-paused" id="pinsaver_pause'+this.full+'"></a>'
                                    + '<a class="pinsaver__block-process-stop pinsaver__block-process-button" id="pinsaver_stop'+this.full+'"></a>'
                                  + '</div>'
                                  + '<div class="pinsaver__block-switch-container">'
                                    + '<label class="pinsaver__block-switch">'
                                      + '<input type="checkbox" disabled />    <div class="pinsaver__block-switch-circle"></div>'
                                      + '<span class="pinsaver__block-switch-text">+ save descriptions(paid mode)</span>'
                                    + '</label>'
                                  + '</div>'
                                  + '<div class="pinsaver__block-description">'
                                    + '<img src="chrome-extension://'+this.id+'/images/text-description.png" alt=""/>'
                                  + '</div>'
                              + ( !this.policyAgree &&
                                  '<div class="pinsaver__block-messageText" id="pinsaver_agree"><div class="pinsaver__block-messageText-container">' +
                                    'Please read PinDown <a href="http://pindown.tk" target="_blank" class="pinsaver__block-messageText-link">Privacy Policy</a> about Your sensitive and personal data first.' +
                                    '<div class="pinsaver__block-agreeButton" id="pinsaver_agree_button">I have read, understand and agree, let\'s continue!</div>' +
                                  '</div></div>'
                              || '')
							  + '<a class="pinsaver__block-close" id="pinsaver_close'+this.full+'">'
								+ '<img src="chrome-extension://'+this.id+'/images/close.png" alt=""/>'
							  + '</a>'
							  + '<div class="pinsaver__block-images" id="pinsaver_images'+this.full+'"></div>'
							  + '<div class="pinsaver__block-ialpha"></div>'
							  + '<div class="pinsaver__block-loader" id="pinsaver_loader'+this.full+'"></div>'
							  + '<div class="pinsaver__block-finish" id="pinsaver_fin'+this.full+'"></div>'
							  ;

			this.block = block;
			document.body.appendChild(block);

            this.button = button;
            document.body.appendChild(button);

			this.imageBlock = PinSaver.byId('pinsaver_images' + this.full);
			this.staticBlock = PinSaver.byId('static_close' + this.full);

			if ( !this.policyAgree ) {
			    this.policyBlock = PinSaver.byId('pinsaver_agree');
                PinSaver.byId('pinsaver_agree_button').onclick = this.onPolicyAgree.bind(this);
            }

            this.loaderBlock = PinSaver.byId('pinsaver_loader' + this.full);
            this.runButton = PinSaver.byId('pinsaver_run' + this.full);
            this.saveFolder = PinSaver.byId('pinsaver_folder' + this.full);
            this.processContainer = PinSaver.byId('pinsaver_process' + this.full);
            this.pauseButton = PinSaver.byId('pinsaver_pause' + this.full);

            this.pauseButton.onclick = this.onPause.bind(this);
            PinSaver.byId('pinsaver_stop' + this.full).onclick = this.onAbort.bind(this);
            this.saveFolder.value = this.folderPrefix + document.title.replace(/[^a-z0-9 _-]/gi, '').replace(/ /gi, '-');

            this.attachLoader().then(() => {
                this.runButton.onclick = this.runAction.bind(this);
            });

            this.runSelf = 25;

            bg.onclick = this.switchBlock.bind(this, true);
            button.onclick = this.switchBlock.bind(this, false);
            PinSaver.byId('pinsaver_close' + this.full).onclick = this.switchBlock.bind(this, true);

            if ( document.location.hash === '#pinDown' ) {
                this.switchBlock();
            }

        },

        updateLoaderVal() {
            if ( !this.loaderJS || !this.loaderJS.setValue ) {
                return;
            }
            if ( this.pinNum !== -1 ) {
                PinSaver.log("Pins num: " + (this.pinNum < 1000 ? this.pinNum : '~' + this.pinNum));
                this.loaderJS.setValue(this.pinNum < 1000 ? this.pinNum : '~' + this.pinNum);
                this.loaderJS.setReal(false);
            } else {
                PinSaver.log("Pins num: unknown or unlimited");
                this.loaderJS.setValue("∞");
                this.loaderJS.setReal(0);
            }
        },


		//--------- CLICK START BUTTON ---------

		runAction: function() {
			if (this.inProgress) {
				return;
			}

			if ( (this.pinNum > 3000 || this.pinNum === -1)
				&& !confirm("There is " + (this.pinNum === -1 ? 'unknown pin number' : 'more than 3000 pins') + ". This may be slow operation. Are you sure?")
			) {
				return;
			}

			window.onbeforeunload = function (e) {
				var message = "Retrieving data is in progress.\nIf you close tab now, some images will be lost.";
				e = e || window.event;
				if (e) {
					e.returnValue = message;
				}
				return message;
			};

			this.aborted = false;
			this.startJSONProcess();
		},

		onStart: function() {
			this.inProgress = true;
			this.saveFolder.setAttribute('disabled', 'disabled');

			if ( this.saveFolder.value == '' ) {
				this.saveFolder.value = 'PinDown ' + Date.now();
			}

			if ( !this.finished ) {
                PinSaver.switchClass(this.loaderBlock, 'pinsaver-visible');
            } else {
                const state = PinSaver.byId('pinsaver_fin' + this.full);
                state.style.display = 'none';
                state.className = state.className.replace(' pinsaver-visible', '');
            }

			PinSaver.switchClass(this.runButton, 'pinsaver-progress');
			PinSaver.switchClass(this.loaderBlock, 'pinsaver-pulsate');
			PinSaver.switchClass(this.processContainer, 'pinsaver-visible');
		},

        onPause() {
            if ( this.paused ) {
                this.pauseButton.classList.add('pinsaver-paused');
                this.setPaused(false);
            } else {
                this.pauseButton.classList.remove('pinsaver-paused');
                this.setPaused(true);
            }
            this.paused = !this.paused;
        },

        onAbort() {
            this.aborted = true;
            this.setAbort();
            this.onFinish(true);
            this.resetUI(true);

        },

        onPolicyAgree() {
		    this.setPolicyAgree();
            this.policyBlock.classList.add('hidden');
        },


		//--------- TOP BLOCK SHOW/HIDE ---------

		switchBlock: function(end) {
			var body = document.body;

			if (
				(!end && !(this.block.className.match('pinsaver-opened') && !body.className.match('pinsaver-animated')) )
				||
				(end && body.className.match('pinsaver-animated'))
			) {
                PinSaver.switchClass(document.body, 'pinsaver-animated');
			}

			PinSaver.switchClass(this.block, 'pinsaver-opened');
			PinSaver.switchClass(this.staticBlock, 'pinsaver-visible');
		},

		switchPinButton: function(show) {
            if ( this.showPinButton && (show === undefined || show) ) {
                this.button.style.display = 'block';
                return;
            }

            this.button.style.display = 'none';
		},


		//--------- ADD CIRCLE PROGRESS LOADER ---------

		attachLoader: function() {
			this.loaderJS = new PercentageLoader(this.loaderBlock, {
				width: 165,
				height: 165,
				controllable: false,
				progress: 0.0,
				value: '0',
				onProgressUpdate: function (val) {
					this.setValue(Math.round(val * 100.0));
				}
			});
            return new Promise(resolve => {
                this.loaderJS.loaded(resolve);
            });
		},

		pushHeadIMG: function(src) {
			var div = document.createElement('div'),
				img = document.createElement('img');

			div.className = 'pinsaver__block-images_div';
            img.className = 'pinsaver__block-images_image';
			img.src = src;

			this.imageBlock.appendChild(div);
			div.appendChild(img);
		},

		saveCollection: function(save) {
            if ( this.aborted ) {
                return;
            }

            const collection = save.reduce((prev, next) => {
                if ( this.collection.id.indexOf(next.id) === -1 ) {
                    this.collection.id.push(next.id);
                    this.collection.links.push(next.url);
                    prev.push(Object.assign({}, next, {
                        url: next.url.match('http') ? next.url : window.location.protocol + '//' + window.location.host + next.url,
                        replace: next.replace ?
                            (next.replace.match('http') ? next.replace : window.location.protocol + '//' + window.location.host + next.replace)
                            : undefined,
                    }));
                } else {
                    PinSaver.log('Already exist', next.id, next.url);
                }
                return prev;
            }, []);

            this.sendImages(collection);
		},

		checkCollection: function() {
			if ( this.collection.id.length >= this.runAt*this.runSelf-1 ) {
				return false;
			}
			return true;
		},

        resetCollection: function () {
            this.collection = {
                id: [],
                links: []
            };
        },


		backgroundLister: function() {
			chrome.runtime.onMessage.addListener((message) => {
                // TODO сохранять данные для активной закачки, когда пользователь вдруг перешёл на другой экран
                // при этом убрать onbeforeunload
                // TODO двойная загрузка при F5/входе
				if (message.status === 'onUpdate' ) {
					if ( message.changeInfo && message.changeInfo.status === 'complete' ) {
						this.resetUI(this.url === location.href);
                        this.title = document.title;
                        this.url = location.href;

                        let waitReady = this.prepareDataReady;

                        if ( this.prepareDataEveryTime && waitReady.__pindown_getState() !== 'pending' ) {
                            waitReady = this.prepareData();
                        }

                        waitReady
                            .then(this.setData)
                            .then(this.switchPinButton.bind(this));

					} else if ( message.changeInfo.status ) {
						this.setParse();
					}

				} else if (message.status === 'saved') {
                    if ( this.aborted || !this.inProgress ) {
                        return;
                    }

                    this.savedItems++;

                    let max = this.pinNum;
                    if ( this.pinNum === -1 ) {
                        this.loaderJS.setProgress(0);
                        this.loaderJS.setReal(this.savedItems);
                        max = '∞';
                    } else {
                        this.loaderJS.setProgress((this.savedItems / Number(this.pinNum)) || 1);
                    }

                    document.title = this.inProgressChar + ' ' + this.savedItems + '/' + max + '  ' + this.title;

                    if (
                        this.pinNum !== -1 &&
                        this.savedItems >= this.pinNum &&
                        !this.finished
                        || this.savedItems >= this.runAt*this.runSelf-1
                    ) {
                        this.onFinish();
                    }

                } else if (message.status === 'finish' && !this.finished) {
                    if ( this.aborted ) {
                        return;
                    }

                    this.onFinish();

                } else if (message.status === 'pageAction' && this.block !== null ) {
                    this.switchBlock();

                } else if (message.status === 'StopFree' && this.full === '' && this.stopped === false) {
                    PinSaver.log('STOP SIGNAL');
                    PinSaver.remove(this.block);
                    PinSaver.remove(this.staticBlock);
                    this.stopped = true;
                } else if ( message.status === 'error' ) {
				    if ( PinSaver.raven_enabled ) {
                        const context = PinSaver.Raven.getContext();
                        PinSaver.Raven.setExtraContext(Object.assign({}, context, {error: message.file}));
                        PinSaver.Raven.captureMessage('File saving error', {
                            level: 'error',
                            errorMessage: message.file
                        });
                    }
                } else if (
                    message.status === 'CORSData'
                    && typeof this.CORSBGResolver[message.id] === 'function'
                ) {
                    this.CORSBGResolver[message.id](message.data);
                    delete this.CORSBGResolver[message.id];
                }
			});
		},

        // -------- COLLECTION WITH ADAPTERS --------

		startJSONProcess: function() {
			this.setStart();
			this.onStart();

			if ( (this.isInstagram || this.isTumblr) && this.currentPins ) {
                this.collect(this.currentPins);
			} else if ( (this.isHostx || this.isBehance) && this.currentPins ) {
                this.saveCollection(this.currentPins);
            }

            this.fetch();
			document.title = this.inProgressChar + ' ' + document.title;
		},

		fetch: function() {
            if ( this.aborted ) {
                return;
            }

			this.getData(true)
				.then(this.fetchData);

		},

		collect: function(pins, isLast) {
            this.saveCollection(this.collectData(pins));
			if ( isLast ) {
				this.setFinishCount(this.collection.id.length);
			}
		},


		// -------- ACTIONS --------

		hideAction: function() {
			try {
				chrome.runtime.sendMessage({status: 'hideAction'});
			} catch (e) {}
		},

		showAction: function() {
			try {
				chrome.runtime.sendMessage({status: 'showAction'});
			} catch (e) {}
		},

		setTitle: function(text) {
			try {
				chrome.runtime.sendMessage({status: 'setTitle', text: text});
			} catch (e) {}
		},

		setBadge: function(text) {
			try {
				chrome.runtime.sendMessage({status: 'setBadge', text: text});
			} catch (e) {}
		},

		setStart: function() {
			try {
				chrome.runtime.sendMessage({
                    status: 'start',
                    name: this.currentBoardName,
                    saveFolder: this.saveFolder.value
				});
			} catch (e) {}
		},

        setPaused(paused) {
            try {
                chrome.runtime.sendMessage({status: 'pause', paused});
            } catch (e) {}
        },

        setAbort() {
            try {
                chrome.runtime.sendMessage({status: 'abort'});
            } catch (e) {}
        },

        setURLs() {
            try {
                chrome.runtime.sendMessage({
                    status: 'url_list',
                    links: this.collection.links,
                    saveFolder: this.saveFolder.value,
                    url: location.href,
                    name: this.saveFolder.value.replace(this.folderPrefix, '')
                });
            } catch (e) {}
        },

		setFinishCount: function(count) {
			try {
				chrome.runtime.sendMessage({status: 'finish', text: count});
			} catch (e) {}
		},

		setParse: function() {
			this.setTitle('Parsing...');
			this.setBadge('...');
		},

		stopFreeVersion: function() {
			if ( this.full !== '' ) { // send msg if FULL
				var talkTo = 'hojoabneemdhaakgfkmiaeafjjlcaebp'; // Free ver ID
				//var talkTo = 'fdpnmpcakcmbhadobpeddinibijpellp'; // test
				try {
					chrome.runtime.sendMessage(talkTo, {status: 'StopFree', full: this.full});
				} catch (e) {}
			}
		},

        setPolicyAgree() {
            this.policyAgree = true;
            chrome.storage.local.set({policyAgree: true});
        },

        sendImages(images) {
            if ( this.aborted ) {
                return;
            }

            try {
                chrome.runtime.sendMessage({
                    status: 'save',
                    images
                });
            } catch (e) {}
        },

        /**
         * Returns CORS data using background script
         * @param url           string      page url
         * @param headers       object      headers for request
         * @param returnData    array       array of strings like "data.images" or "posts"
         * @param parse         boolean     set true, if request returns no JSON
         * @returns {Promise}
         */
		getCORSData(url, headers, returnData, noParse) {
		    const currentPromiseTimer = Date.now();

            chrome.runtime.sendMessage({
                status: 'getCORS',
                id: currentPromiseTimer,
                url,
                headers,
                noParse,
                returnData
            });

		    return new Promise(resolve => {
                this.CORSBGResolver[currentPromiseTimer] = resolve;
            });
        },


		//--------- END ---------

		onFinish: function(softReset) {
            this.setURLs();
			this.inProgress = false;
            this.savedItems = 0;
            this.finished = true;

            PinSaver.switchClass(this.runButton, 'pinsaver-progress');
			PinSaver.switchClass(this.loaderBlock, 'pinsaver-pulsate');
            PinSaver.switchClass(this.processContainer, 'pinsaver-visible');

            this.loaderJS.setProgress(1);
            this.loaderJS.setValue(this.collection.id.length+1);
            this.saveFolder.removeAttribute('disabled');

			const state = PinSaver.byId('pinsaver_fin' + this.full);
			state.style.display = 'block';
			state.classList.add('pinsaver-visible');

			if ( (this.pinNum !== -1 && this.pinNum < 250) || (this.pinNum === -1 && this.collection.id.length < 249) ) {
                state.innerText = 'Finished!';

			} else if( !softReset ) {
                state.classList.add('pinsaver-free');
                state.innerText = 'Limit reached';
                PinSaver.select('canvas', PinSaver.byId('pinsaver_loader' + this.full)).nextElementSibling.innerText = 250;

                const link = document.createElement('a');
                link.href = 'https://chrome.google.com/webstore/detail/pindown/flieckppkcgagklbnnhnkkeladdghogp?authuser=0';
                link.className = 'pinsaver__block-full';
                link.target = '_blank';
                link.id = 'pinsaver__getfull';
                link.innerHTML = 'Get&nbsp;&nbsp;full&nbsp;&nbsp;version&nbsp;&nbsp;for&nbsp;&nbsp;<span class="pinsaver__block-full-price">1.99$/month</span>';
                this.block.appendChild(link);
			}

			this.resetCollection();

			document.title =  this.title;
            window.onbeforeunload = null;
		}

	};

    if ( chrome && chrome.runtime && chrome.runtime.id ) {
        PinDown.init();
    }

})})();