'use strict';

const pinsaver_debug = true;

var PinSaver = PinSaver || {};
PinSaver.raven_enabled = false;

PinSaver.get = function(url, headers, noParse) {
    PinSaver.log(JSON.stringify(PinSaver.getQueryParameters(url)));
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.onload = function() {
            if ( this.readyState === 4 && this.status !== 200 ) {
                let url_string = url;
                const http = url.match(/https?:\/\/(.*)/);
                if ( http ) {
                    url_string = http[1];
                }
                PinSaver.captureException(`:::XMLHttpRequest error ${url_string.split('/')[0]}`, {
                    level: 'error',
                    responseText: noParse ? this.responseText : JSON.parse(this.responseText || {})
                });
                reject(this);
                return;
            }

            if ( noParse ) {
                resolve(this.responseText);
                return;
            }

            try {
                const json = JSON.parse(this.responseText || {});
                resolve(json);
            } catch (e) {
                PinSaver.captureException(':::XMLHttpRequest JSON parse error', {
                    error: e,
                    responseText: this.responseText
                });
                reject(this);
            }

        };
        xhr.open('GET', url);
        xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        if ( headers ) {
            Object.keys(headers).forEach(function (key) {
                xhr.setRequestHeader(key, headers[key]);
            });
        }
        xhr.send();
    });
};

PinSaver.captureException = function(message, exception) {
    if ( !PinSaver.raven_enabled || !window['Raven'] ) {
        return;
    }
    const context = window['Raven'].getContext();
    window['Raven'].setExtraContext(Object.assign({}, context, exception));
    window['Raven'].captureMessage(message, {
        level: 'error'
    });
};

PinSaver.Raven = {
    init: function(cb) {
        if ( !PinSaver.raven_enabled ) {
            cb();
            return;
        }
        window['Raven'].context(cb);
    },
    setUserContext: function(data) {
        if ( !PinSaver.raven_enabled ) {
            return;
        }
        window['Raven'].setUserContext(data);
    },
    setExtraContext: function(data) {
        if ( !PinSaver.raven_enabled ) {
            return;
        }
        window['Raven'].setExtraContext(data);
    },
    captureMessage: function(msg, data) {
        if ( !PinSaver.raven_enabled ) {
            return;
        }
        window['Raven'].captureMessage(msg, data);
    },
    getContext: function () {
        if ( !PinSaver.raven_enabled ) {
            return false;
        }
        return window['Raven'].getContext();
    }
};

PinSaver.getQueryParameters = function(str) {
    return (str || document.location.search)
        .replace(/(^\?)/, '')
        .split("&")
        .map(function(n){return n = n.split("="), this[n[0]] = n[1], this}.bind({}))[0];
};

PinSaver.log = function(...args) {
    if ( !pinsaver_debug ) {
        return;
    }
    const arg = [...args];
    arg.unshift('[ pindown ] ');
    console.log.apply(window, arg);
};

PinSaver.DOMParser = function(text) {
    const parser = new DOMParser();
    return parser.parseFromString(text, "text/html");
};
