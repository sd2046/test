'use strict';

var PinSaver = PinSaver || {};

String.prototype.__pindown_stripSlash = function() { return this.replace('/','') };

if (window.Promise) {
    Promise.prototype.__pindown_getState = function () {
        if (!this.state) {
            this.state = "pending";
            var that = this;
            this.then(
                function (v) {
                    that.state = "resolved";
                    return v;
                },
                function (e) {
                    that.state = "rejected";
                    return e;
                });
        }
        return this.state;
    };
}

PinSaver.byId = function(id) {
    return document.getElementById(id);
};

PinSaver.byClass = function(text, el) {
    if (el) {
        return el.getElementsByClassName(text);
    } else {
        return document.getElementsByClassName(text);
    }
};

PinSaver.byTag = function(text, el) {
    if (el) {
        return el.getElementsByTagName(text);
    } else {
        return document.getElementsByTagName(text);
    }
};

PinSaver.select = function(query, el) {
    if (el) {
        return el.querySelector(query);
    } else {
        return document.querySelector(query);
    }
};

PinSaver.selectAll = function(query, el) {
    if (el) {
        return el.querySelectorAll(query);
    } else {
        return document.querySelectorAll(query);
    }
};

PinSaver.remove = function(el) {
    el.parentElement.removeChild(el);
};

PinSaver.switchClass = function(el, text) {
    if ( !el.className.match(text) ) {
        el.className = el.className + ' ' + text;
    } else {
        el.className = el.className.replace(' ' + text, '');
    }
};

/**
PinSaver.eventFire = function(el, etype) {
    if (el.fireEvent) {
        el.fireEvent('on' + etype);
    } else {
        const evObj = document.createEvent('Events');
        evObj.initEvent(etype, true, false);
        el.dispatchEvent(evObj);
    }
};
*/

PinSaver.simplify = function(text) {
    if ( typeof text === 'number' ) {
        return text;
    }

    if ( !text ) {
        return Date.now();
    }

    return text.replace(/[^a-zа-яA-ZА-Я0-9 _-]/gi, '')
        .replace(/ /gi, '-')
};

PinSaver.getNumber = function(num) {
    if ( num < 1000 ) {
        return num;
    }
    if ( num / 1000 > 1 && num < 999999 ) {
        return parseInt(num/1000) + 'k';
    }
    if ( num / 1000000 > 1 && num < 999999999 ) {
        return parseInt(num/1000000) + 'M';
    }
    if ( num / 1000000000 > 1 ) {
        return parseInt(num/1000000000) + 'b';
    }
};

/**
PinSaver.zeroPad = function(n, w){
    while(n.toString().length<w) n = '0' + n;
    return n;
};
*/

PinSaver.fromNumbers = function(nums){
    let s = '';
    for(let i=0; i<nums.length; i+=3){
        s += String.fromCharCode(nums.substring(i, i+3));
    }
    return s;
};

PinSaver.getCookieValueFromKey = function(key, cookies) {
    const cookie = cookies.find(c => c.indexOf(key) !== -1);
    if (!cookie) {
        throw new Error('No key found.');
    }
    return (new RegExp(key + '=(.*?);', 'g').exec(cookie))[1];
};

PinSaver.calcNum = function(str) {
    let parsed = str.toString()
        .replace(/ repins/gi, '')
        .replace(/ likes/gi, '')
        .replace(/ pins/gi, '')
        .replace(/,/, '')
        .replace(/\//, '-')
        .replace(' ', '')
        .replace(' ', '');

    if ( parsed.match('k') ) {
        parsed = Number(parsed.replace('k', '')) * 1000;
    }

    return parseInt(parsed);
};

PinSaver.makeName = function(domain, description) {
    return domain + ' ' + PinSaver.simplify(description).substr(0, 45).replace(/--*/g, '-');
};