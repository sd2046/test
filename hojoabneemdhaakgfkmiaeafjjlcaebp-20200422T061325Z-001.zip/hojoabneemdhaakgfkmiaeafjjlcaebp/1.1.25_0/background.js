var queue = {
	parallelSave: 4,
    parallelSaveDisable: false,
    descriptionsToSubfolder: true,

	files: {},
	folders: {},
	counts: {},
    names: {},
    queue: {},
    progress: {},
    aborted: {},
    paused: {},
    pauseCounter: {},
    downloadMapping: {},
    saveDescriptions: {},

    // TODO скачивать файлы со вкладок не сразу, а одну за другой
	init: function(tab, options) {
		console.log("START tab: %s", tab);

        delete this.aborted[tab];

		this.files[tab] = [];
		this.queue[tab] = [];
        this.progress[tab] = [];

		this.counts[tab] = {
			total: false,
			saved: 0
		};

        this.paused[tab] = false;
        this.pauseCounter[tab] = 0;
        this.names[tab] = options.name;
        this.folders[tab] = options.saveFolder;
        this.saveDescriptions[tab] = options.saveDescriptions;
	},

	setCount: function(tab, count) {
        if ( !this.counts[tab] ) {
            return;
        }

		if ( this.counts[tab].saved >= count ) {
			this.sendFinish(tab);
			return;
		}

		this.counts[tab].total = count;
	},

    abort: function(tab) {
        this.aborted[tab] = true;
        this.removeTabSettings(tab);
    },

    pause(tab) {
        this.paused[tab] = true;
    },

    resume(tab) {
        this.paused[tab] = false;

        if ( this.parallelSaveDisable ) {
            this.queue[tab].forEach(this.save);
            return;
        }

        this.pauseCounter[tab] = 0;
        for (; this.pauseCounter[tab] < this.parallelSave; this.pauseCounter[tab]++) {
            this.checkForNext(tab);
        }
    },

    downloadFile: function(message, tab) {
        if ( this.aborted[tab] ) {
            return;
        }

        var filename = getFilename(message.url),
            ext = getExtension(filename),
            subfolder = '';

        if ( ext === 'gif') {
            subfolder = '/gif';
        } else if ( ['mp4', 'webm', 'avi', 'flv'].indexOf(ext) > -1 ) {
            subfolder = '/video';
        }

        if ( this.files[tab].indexOf(filename) > -1 ) {
            console.log("[%d %d] %s | DUPLICATE %s %s", tab, this.files[tab].length, Number(new Date), filename, message.url);
            this.checkFinish(tab);
            return;
        }

        console.log("[%d %d] %s | ADD %s, %s", tab, this.files[tab].length, Number(new Date), filename, message.url);

        this.files[tab].push(filename);
        const options = {message, subfolder, filename, tab, num: this.files[tab].length};

        if ( this.parallelSaveDisable && !this.paused[tab] ) {
            this.progress[tab].push(options);
            this.save(options);
            return;
        }

        this.queue[tab].push(options);

        if ( !this.paused[tab] ) {
            this.checkForNext(tab);
        }
    },

    checkForNext(tab) {
        if ( this.progress[tab].length <= this.parallelSave ) {
            this.downloadNext(tab);
        }
    },

    downloadNext(tab) {
        if ( this.parallelSaveDisable || this.aborted[tab] || this.paused[tab] ) {
            return;
        }

        const item = this.queue[tab].shift();
        if ( !item ) {
            return;
        }

        this.progress[tab].push(item);
        this.save(item);
    },

	checkFinish: function(tab) {
        if ( this.aborted[tab] ) {
            return;
        }

		chrome.tabs.sendMessage(tab, {status: "saved"});
		this.counts[tab].saved++;

		console.log('-> ', this.counts[tab].saved, this.counts[tab].total) ;

		if ( !this.counts[tab].total || this.counts[tab].saved < this.counts[tab].total ) {
			return;
		}

		this.removeTabSettings(tab);
		this.sendFinish(tab);
	},

    removeTabSettings(tab) {
        ['counts', 'files', 'names', 'progress', 'folders', 'paused'].forEach((context) => delete this[context][tab]);
    },

	sendFinish: function(tab) {
		chrome.tabs.sendMessage(tab, {status: "finish"});
	},

	save(options) {
        console.log("[%d %d] %s | START %s, %s", options.tab, options.num, Number(new Date), options.filename, options.message.url);

        if ( this.saveDescriptions[options.tab] ) {
            const fileOptions = [options.tab, options.filename];
            if (options.message.description) {
                this.saveDescription.apply(this, fileOptions.concat([options.message.description, 'txt']));
            }

            if (options.message.description_html) {
                this.saveDescription.apply(this, fileOptions.concat([options.message.description_html, 'html.txt']));
            }

            if (options.message.description_link) {
                this.saveDescription.apply(this, fileOptions.concat([options.message.description_link, 'url.txt']));
            }
        }

		chrome.downloads.download({
			url: options.message.url,
			filename: this.folders[options.tab] + options.subfolder + '/' + options.filename,
			conflictAction: 'overwrite'
		});
	},

    saveURLs(options) {
        this.saveDescription(
            undefined,
            `${options.saveFolder}/URL`,
            `${options.name}\r\n${options.url}\r\n\r\n${options.links.join("\r\n")}`,
            'txt'
        )
    },

	saveDescription(tab, file, description, ext) {
        const subfolder = this.descriptionsToSubfolder ? '/descriptions/' : '/';
		chrome.downloads.download({
			url: URL.createObjectURL(new Blob([description], {type: 'text/plain'})),
            conflictAction: 'overwrite',
			filename: (this.folders[tab] || '') +
                      (!!tab ? subfolder : '') +
                      file + '.' + ext
		});
	},

    onChangeCallback(file) {
        let filename;
        const isCreate = file.filename && file.filename.previous === '';
        const isComplete = file.state && file.state.current === 'complete';
        const hasError = file.error;

        if ( isCreate ) {
            filename = getFilename(file.filename.current);
            const ext = getExtension(filename);
            if ( ['txt', 'html', 'url'].indexOf(ext) > -1 ) {
                return;
            }

            const { fileOptions } = this.findDownload(filename);
            this.downloadMapping[file.id] = fileOptions;
        }

        if ( !isComplete && !hasError ) {
            return;
        }

        let options = this.downloadMapping[file.id];

        // downloaded before creating (pause)
        if ( !options ) {
            const { fileOptions } = this.findDownload(filename);
            if ( !fileOptions ) {
                return;
            }
            options = fileOptions;
        }

        if ( this.aborted[options.tab] ) {
            return;
        }

        if ( hasError && hasError.current === 'SERVER_FORBIDDEN' ) {
            // chrome.tabs.sendMessage(options.tab, {status: "error", file});
            this.reSave(options, file.id);
            return;
        }

        this.progress[options.tab].splice(this.progress[options.tab].indexOf(options), 1);
        this.saveNext(file.id, options.tab);

        console.log("[%d %d] %s | FINISH %s", options.tab, options.num, Number(new Date), options.filename);
    },

    findDownload(filename) {
        let fileTab;
        let fileOptions;

        for(let tab in this.progress) {
            this.progress[tab].forEach((download, i) => {
                const optionsFileName = getFilename(download.message.url);
                if ( filename === optionsFileName ) {
                    fileTab = tab;
                    fileOptions = this.progress[tab][i];
                }
            });
        }

        return { fileTab, fileOptions };
    },

    reSave(options, id) {
        console.log("[%d %d] %s | FORBIDDEN %s", options.tab, options.num, options.filename, options.message.url);
        if ( !options.message.replace ) {
            this.downloadNext(options.tab);
            return;
        }

        this.downloadMapping[id].message.url = this.downloadMapping[id].message.replace;
        delete this.downloadMapping[id].message.replace;

        this.save(options);
    },

    saveNext(currentId, tab) {
        delete this.downloadMapping[currentId];
        this.downloadNext(tab);
        this.checkFinish(tab);
    }
};

queue.save = queue.save.bind(queue);

chrome.downloads.onChanged.addListener(queue.onChangeCallback.bind(queue));

var free_unloaded = false;
chrome.runtime.onMessageExternal.addListener(function(message, sender) {
	if ( message.status === 'StopFree' && message.full !== '') {
		free_unloaded = true;
		chrome.browserAction.disable(sender.tab.id);
		chrome.tabs.sendMessage(sender.tab.id, {status: message.status});
		console.log('STOP SIGNAL');
	}
});

chrome.runtime.onMessage.addListener(function(message, sender) {
	if (free_unloaded === true) {
		console.log('i am stopped');
		return;
	}

	switch(message.status) {
        case 'save':
            message.images.forEach((image) => queue.downloadFile(image, sender.tab.id));
            break;

        case 'start':
		    queue.init(sender.tab.id, message);
		    break;

        case 'finish':
		    queue.setCount(sender.tab.id, message.text);
            break;

        case 'abort':
		    queue.abort(sender.tab.id);
            break;

        case 'pause':
            if ( message.paused ) {
                queue.pause(sender.tab.id);
            } else {
                queue.resume(sender.tab.id);
            }
            break;


        case 'url_list':
            queue.saveURLs(message);
            break;

        case 'showAction':
            if (free_unloaded === false ) {
                chrome.browserAction.enable(sender.tab.id);
            }
            break;

        case 'hideAction':
		    chrome.browserAction.disable(sender.tab.id);
            break;

        case 'setTitle':
            chrome.browserAction.setTitle({
                tabId: sender.tab.id,
                title: String(message.text)
            });
            break;

        case 'setBadge':
            chrome.browserAction.setBadgeText({
                tabId: sender.tab.id,
                text: String(getNum(message.text))
            });
            break;

        case 'getCORS':
            PinSaver
                .get(message.url, message.headers, message.noParse)
                .then(data => {
                    if (message.noParse) {
                        return data;
                    }

                    if (!message.returnData || message.returnData.length === 'undefined') {
                        return {};
                    }

                    const storedData = {};

                    message.returnData.forEach(string => {
                        if ( string.match(/\./) === null ) {
                            storedData[string] = data[string];
                            return;
                        }

                        // TODO not tested next functionality for object selection (e.g. "posts.images.data")

                        const splitStr = string.split('.');
                        let name = splitStr[splitStr.length - 1];
                        if ( storedData[name] ) {
                            name += Date.now();
                        }

                        storedData[name] = data;

                        splitStr.some(obj => {
                            const currentObj = storedData[name][obj];
                            if ( typeof currentObj === 'undefined' ) {
                                return true;
                            }
                            storedData[name] = currentObj;
                        });

                    });

                    return storedData;
                })
                .catch(data => ({ hasError: true, response: data.response }))
                .then(data => {
                    chrome.tabs.sendMessage(sender.tab.id, {
                        status: 'CORSData',
                        id: message.id,
                        data
                    });
                });
            break;
    }
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	chrome.tabs.sendMessage(tab.id, {status: 'onUpdate', tabId: tabId, changeInfo: changeInfo});
});

chrome.browserAction.onClicked.addListener(function(tab) {
	if (free_unloaded === true) {
		return;
	}
	chrome.tabs.sendMessage(tab.id, {status: 'pageAction'});
});

chrome.runtime.onInstalled.addListener(function(details) {
	if (details.reason == "install") {
		chrome.tabs.create({'url': chrome.extension.getURL('install.html')});
	}
	/*
	else if(details.reason == "update") {
		chrome.tabs.create({'url': chrome.extension.getURL('whatsnew.html')});
	}
	*/

    chrome.management.getSelf(function(self){
        if ( self.id === 'flieckppkcgagklbnnhnkkeladdghogp' || self.id === 'fdpnmpcakcmbhadobpeddinibijpellp' ) {
            chrome.management.setEnabled('hojoabneemdhaakgfkmiaeafjjlcaebp', false);
        }
    });
});

function getFilename(url) {
	const file = url.split(url.match('/') ? '/' : '\\').pop();
	// remove abc.png?someparams=domain.com
	if ( !/\.[a-zA-Z0-9]{1,5}\?/.test(file) ) {
	    return file;
    }
    const chunks = file.split('?');
	return chunks[chunks.length - 2];
}

function getExtension(filename) {
	var regexp = /(?:\.([^.]+))?$/;
	return regexp.exec(filename)[1].toLowerCase();
}

function strip(filename) {
	if (filename.match('\\?')) {
		filename = filename.split('?')[0]
	}
	return filename;
}

function getNum(num) {
	var int = parseInt(num);
	if ( int && int > 999 ) {
		return parseInt(int/1000) + 'k';
	}
	return num;
}
