'use strict';

var sharedOptions = (function(isOptions) {

    const storage = chrome.storage.local;
    const byId = (id) => document.getElementById(id);
    const keys = {
        'parallelSave': 4,
        'parallelSaveDisable': false,
        'folderPrefix': 'PinDown__',
        'descriptionsToSubfolder': true,
        'gifToSubfolder': true,
        'saveDescriptions': false,
        'showPinButton': true,
        'policyAgree': false
    };
    const keysArr = Object.keys(keys);

    class options {
        constructor() {
            this.updateOptions = this.updateOptions.bind(this);
            this.setFieldListener = this.setFieldListener.bind(this);
            this.keyListener = this.keyListener.bind(this);
            this.switchListener = this.switchListener.bind(this);
            if ( isOptions ) {
                this.setStorageOptions();
                this.setListeners();
            }
        }

        setStorageOptions() {
            this.getOptions()
                .then(this.updateOptions);
        }

        updateOptions(options) {
            keysArr.forEach(key => {
                const field = byId(key);
                if ( !field ) {
                    return;
                }
                if ( typeof keys[key] !== "boolean" ) {
                    field.value = typeof options[key] !== 'undefined' ? options[key] : keys[key];
                    return;
                }

                if ( (typeof options[key] === 'undefined' && keys[key]) || options[key] ) {
                    if ( key === 'parallelSaveDisable' ) {
                        this.handleParallel(true);
                    }
                    field.setAttribute('checked', 'checked');
                    return;
                }

                field.removeAttribute('checked');
            });
        }

        setListeners() {
            keysArr.forEach(this.setFieldListener);
        }

        setFieldListener(key) {
            const field = byId(key);

            if ( !field ) {
                return;
            }

            let fn;

            if ( field.getAttribute('type') !== 'checkbox' ) {
                fn = this.keyListener;
            } else {
                fn = this.switchListener;
            }

            field.addEventListener('change', fn);
        }

        keyListener(e) {
            const target = e.target;
            this.setOptions({ [target.id]: target.value });
            this.showSaved(target);
        }

        switchListener(e) {
            const target = e.target;
            if ( target.id === 'parallelSaveDisable' ) {
                this.handleParallel(target.checked);
            }
            this.setOptions({ [target.id]: !!target.checked });
            this.showSaved(target.parentElement);
        }

        handleParallel(checked) {
            const input = byId('parallelSave');
            if ( checked ) {
                input.setAttribute('disabled', 'disabled');
            } else {
                input.removeAttribute('disabled');
            }
        }

        showSaved(e) {
            const saveElement = e.parentElement.querySelector('.saved');
            if ( saveElement.showTimeout ) {
                clearTimeout(saveElement.showTimeout);
                delete saveElement.showTimeout;
            }
            saveElement.classList.add('show');
            e.showTimeout = setTimeout(this.hideSaved.bind(saveElement), 2000);
        }

        hideSaved() {
            this.classList.remove('show');
            delete this.showTimeout;
        }

        getOptions() {
            return new Promise(resolve => {
                storage.get(Object.keys(keys), result => {
                    resolve(result);
                });
            })
        }

        setOptions(keys) {
            storage.set(keys);
        }
    }

    if ( isOptions ) {
        new options();
    }

    return {keys, options};

})(true);
