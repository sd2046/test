'use strict';

var PinSaver = PinSaver || {};
PinSaver.adapters = PinSaver.adapters || {};

(function() {

    let page = 2;

    PinSaver.adapters['sx'] = {

        // todo кэшироваине повторных запросов
        getData: function() {
            return PinSaver.get(`${location.href}?page=${page}`, {
                'X-Requested-With': 'XMLHttpRequest'
            }, true).catch( (data) => {
                this.hideAction();
                throw new Error('Error parsing Sx data');
            });
        },

        setData: function() {
            const type = getTypes();

            if (!type) {
                this.hideAction();
                this.setTitle('There is no active boards to save pins');
                this.setBadge('...');
                return;
            }

            this.currentBoardName = type.text;
            this.pinNum = PinSaver.calcNum(type.num || 0);
            this.currentPins = this.collectData([...PinSaver.selectAll('#masonry_container .masonry_box.small_pin_box')]);

            let text = type.num + ' found';
            let badge = PinSaver.getNumber(this.pinNum);

            if (!type.num) {
                this.pinNum = -1;
                text = "Can't detect fixed pin number";
                badge = '∞';
            }

            this.showAction();
            this.updateUI(type.text);
            this.setTitle(text);
            this.setBadge(badge);

            appendImages.call(this);
        },

        fetchData: function(data) {
            if ( this.aborted ) {
                return;
            }

            const document = PinSaver.DOMParser(data);
            const pins = document.querySelectorAll('.masonry_box');
            const zero = pins.length === 0;
            const endOfList = zero || pins.length < 96;

            if ( zero ) {
                return;
            }

            // todo переделать на промисы, сделать вызов из pinsaver с учётом постепенной загрузки
            this.collect(pins, endOfList);

            if ( endOfList ) {
                return;
            }

            page++;
            this.fetch();
        },

        collectData: function(pins) {
            const save = [];
            [...pins].some((pin) => {
                if ( pin.classList.contains('ad_box') || pin.classList.contains('board_info_box') ) {
                    return false;
                }

                const checked = this.checkCollection();
                const href = PinSaver.byClass('image_wrapper', pin);

                if (href.length > 0) {
                    const img = PinSaver.byTag('img', pin);
                    const title = PinSaver.select('.title > a', pin);
                    const id = href[0].href.match(/\/(pin|picture|video)\/(\d+)-/) ||
                               href[0].href.match(/\/(pin|picture|video)\/(\d+)/);

                    let link;
                    if ( PinSaver.select('.play_button', pin) ) {
                        // todo video
                        PinSaver.log("VIDEO");
                        PinSaver.log(pin);
                        return false;
                    } else if (img !== null && img !== undefined && img[0] !== undefined) {
                        link = img[0].dataset.src.replace('/300/', '/620/');
                    }

                    if ( id !== null ) {
                        if ( checked ) {
                            save.push({
                                id: id[2],
                                url: link,
                                description: title !== null ? title.innerText : false,
                                // todo нужна ссылка с оригинала
                                description_link: title !== null ? title.getAttribute('href') : false
                            });
                        }
                    } else {
                        PinSaver.log("NOT FOUND ID");
                        PinSaver.log(pin);
                    }
                } else {
                    PinSaver.log("NOT FOUND HREF");
                    PinSaver.log(pin);
                }

                return !checked;
            });

            // todo resolve original pages using queue x3
            // for (let i = 0; i <= save.length; i = i + 3) {
            //
            // }

            return save;
        },

        resetData: function() {
            page = 2;
        }
    };

    function getTypes() {
        const loc = location.href;
        const path = location.pathname;
        const isBoard = path.match('/user/(.+)/(.+)');
        const isPins = path.match('/user/(.+)/pins');
        const isLikes = path.match('/user/(.+)/likes');
        const isRepins = path.match('/user/(.+)/repins');
        const isSearch = loc.match(/\/search\/(pics|gifs)\?query=(.+)/);
        const isPics = loc.match(/(pics|gifs)\/(.+)/);
        const matches = path.match(/\/(.+)\/(.+)\//);

        if ( isPins ) {
            const num = PinSaver.select('#container .create_board_box li:nth-child(3) > a');
            return {
                text: 'S-' + isPins[1] + '-pins',
                num: num !== null ? num.innerText.replace(' Pins', '') : false
            }

        } else if ( isRepins ) {
            const num = PinSaver.select('#container .create_board_box li:nth-child(4) > a');
            return {
                text: 'S-' + isRepins[1] + '-repins',
                num: num !== null ? num.innerText.replace(' Repins', '') : false
            }

        } else if ( isLikes ) {
            const num = PinSaver.select('#container .create_board_box li:nth-child(5) > a');
            return {
                text: 'S-' + isLikes[1] + '-likes',
                num: num !== null ? num.innerText.replace(' Likes', '') : false
            }

        } else if (
            path.match(/\/user\/[a-zA-Z0-9_.-]*\/$/)
         || path.match('/user/(.+)/following')
         || path.match('/pin/(\d)*-?')
        ) {
            return false;

        } else if (loc.match(/(pics|gifs)\/\?sort/)) {
            return {
                text: 'S-pics-' + Date.now(),
                num: false
            }

        } else if ( isPics ) {
            return {
                text: `S-${isPics[1]}-${isPics[2]}-${Date.now()}`,
                num: false
            }

        } else if ( isBoard ) {
            const num = PinSaver.select('#masonry_container .pinCount');
            return {
                text: `${isBoard[1]}--${isBoard[2]}`,
                num: num !== null ? num.innerText : false
            }
        } else if (
            path === '/' ||
            path === PinSaver.fromNumbers('047115101120045118105100101111115047') ||
            path === PinSaver.fromNumbers('047112111114110045112105099115047') ||
            path === PinSaver.fromNumbers('047112111114110045112105099115045097110100045118105100101111115047')
        ) {
            return {
                text: 'S-' + Date.now(),
                num: false
            }

        } else if ( isSearch ) {
            return {
                text: 'S-' + isSearch[1] + '-' + isSearch[2],
                num: false
            }

        } else if ( matches ) {
            return {
                text: 'S-' + matches[1],
                num: false
            }
        }

        return false;
    }

    function appendImages() {
        [...this.currentPins]
            .splice(0,8)
            .forEach((pin) => {
                this.pushHeadIMG(pin.url);
            });
    }

    function getPin(id) {
        return PinSaver.get(`/pin/ajax/${id}`, {
            'X-Requested-With': 'XMLHttpRequest'
        }, true).catch( () => {
            throw new Error('SX: Error getting pin ' + id);
        });
    }

})();