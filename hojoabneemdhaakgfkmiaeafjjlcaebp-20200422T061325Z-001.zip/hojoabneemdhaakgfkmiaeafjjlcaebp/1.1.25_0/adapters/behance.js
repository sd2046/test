'use strict';

var PinSaver = PinSaver || {};
PinSaver.adapters = PinSaver.adapters || {};

(function() {

    const queue = 3;

    let currentBoardType = null;
    let currentData = [];
    let xpid = null;
    let bcp = null;
    let offset = 0;

    const cache = {};

    PinSaver.adapters['behance'] = {

        prepareData: function() {
            xpid = window.NREUM && window.NREUM.loader_config && window.NREUM.loader_config.xpid;

            if ( !window.NREUM ) {
                const script = [...document.querySelectorAll('script')]
                    .filter(script => script.innerText.match('loader_config'));

                if ( !script || script.length === 0 ) {
                    throw new Error('Can\'t find script with xpid!');
                }

                xpid = script[0].outerText.match(/loader_config=\{xpid:"(.*)"\};/)[1];

                setBCP();
            }

            if ( !xpid ) {
                throw new Error('Can\'t find xpid!');
            }

            if ( !bcp ) {
                return new Promise(resolve => {
                    setTimeout(() => {
                        setBCP();
                        resolve();
                    }, 3000);
                });
            }

            return Promise.resolve();
        },

        getData: function(...args) {
            return getData.apply(this, [...args]);
        },

        setData: function() {
            const type = getTypes();

            if ( !type ) {
                this.hideAction();
                this.setTitle('There is no active boards to save pins');
                this.setBadge('...');
                return;
            }

            this.getData()
                .then( data => {
                    const { name, num, content } = getTypes(data);
                    let badge;
                    let title;
                    let images = [];

                    if ( currentBoardType === 'gallery' ) {
                        images = data.view.project.modules;
                        this.currentPins = this.collectData(images);
                        this.pinNum = this.currentPins.length;
                        badge = this.pinNum;
                        title = this.pinNum + ' resources found';
                    } else {
                        this.pinNum = -1;
                        images = content;
                        offset = 0;
                        badge = '∞';
                        title = 'More then ' + num + ' found';
                    }

                    this.currentBoardName = name;

                    this.showAction();
                    this.updateUI(name);
                    this.setTitle(title);
                    this.setBadge(badge);
                    appendImages.call(this, images);
                });
        },

        fetchData: function(data) {
            if ( this.aborted ) {
                return;
            }

            if ( currentBoardType === 'gallery' ) {
                return;
            }

            if ( currentBoardType === 'projects' ) {
                currentData = data.section_content || data.profile.activeSection.work.projects;
            } else if ( currentBoardType === 'collection' ) {
                currentData = data.output;
            } else if ( currentBoardType === 'appreciated' ) {
                currentData = data.section_content.map(item => item.project);
            } else if ( currentBoardType === 'search' ) {
                currentData = data;
            } else if ( currentBoardType === 'featured' ) {
                currentData = data.projects;
            } else if ( currentBoardType === 'galleries' ) {
                currentData = data.entities;
            }

            if ( currentData.length === 0 ) {
                return;
            }

            const dataQueue = [];
            for (let i = 0; i < queue; i++) {
                dataQueue.push(
                    this.getData(false, currentData[i])
                        .then(getDataNext.bind(this, i, 0))
                );
            }

            Promise
                .all(dataQueue)
                .then(this.fetch);
        },

        collectData: function(pins) {
            const save = [];
            pins.some( pin => {
                if ( pin.is_embed ) {
                    PinSaver.log('Unsupported embed found');
                    PinSaver.log(pin);
                }

                if ( !isAccepted(pin) ) {
                    return false;
                }

                const checked = this.checkCollection();
                if ( checked ) {
                    if ( pin.is_grid ) {
                        save.concat(getGrid(pin));
                    } else {
                        save.push({
                            id: pin.id,
                            url: getUrl(pin)
                        });
                    }
                }

                return !checked;
            });

            return save;
        },

        resetData: function(softReset) {
            if ( !softReset ) {
                currentBoardType = null;
                currentData = [];
            }
            offset = 0;
        }
    };

    function getTypes(data) {
        const path = location.pathname;
        const isGallery = path.match(/\/gallery\/(\d+)*\/(.*)/);
        const isGalleries = path.match(/\/galleries\/(\d+)*\/(.*)/) || path.match(/\/galleries\/[a-zA-Z0-9]*\/(\d+)*\/(.*)/);
        const isCollection = path.match(/\/collection\/(\d+)*\/(.*)/);
        const isProfile = PinSaver.select('.qa-user-work');
        const isSearch = path === "/search";
        const isFeatured = path === "/featured";

        if ( isGallery ) {
            currentBoardType = 'gallery';
            return {
                name: data && data.view.project.name
            };

        } else if ( isProfile || isCollection ) {
            let name = getTitle();
            let content = data && (data.section_content || data.profile.activeSection.work.projects);

            currentBoardType = 'projects';

            if ( path.match('/collections') ) {
                return false;
            } else if ( isCollection ) {
                currentBoardType = 'collection';
                name += ' collection';
                content = data && data.output;
            } else if ( path.match('/appreciated') ) {
                currentBoardType = 'appreciated';
                name += ' appreciated';
            }

            return {
                name,
                content,
                num: content && content.length
            };
        } else if ( isSearch ) {
            if ( location.search.match(/content=(users|teams|collections)/) ) {
                return false;
            }

            currentBoardType = 'search';
            return {
                name: 'Search ' + getTitle() + Date.now(),
                content: data
            };
        } else if ( isFeatured ) {
            currentBoardType = 'featured';
            return {
                name: 'Featured ' + Date.now(),
                content: data && data.projects
            };
        } else if ( isGalleries ) {
            currentBoardType = 'galleries';
            return {
                name: decodeURIComponent(isGalleries[2]) + Date.now(),
                content: data && data.entities
            };
        }

        return false;
    }

    function getData(isFetch, subtree) {
        if ( this.aborted ) {
            return;
        }

        let url = location.pathname;
        switch(currentBoardType) {
            case 'gallery':
                break;
            case 'projects':
            case 'collection':
            case 'appreciated':
                url += '?offset=' + offset;
                break;
            case 'search':
                url = `${location.href}&ordinal=${48 * offset}&per_page=48`;
                break;
            case 'featured':
                url += '?ordinal=' + offset;
                break;
            case 'galleries':
                const page = url.match(/\/galleries\/(\d+)*\/(.*)/);
                const instrument = url.match(/\/galleries\/([a-zA-Z0-9]*)\/(\d+)*\/(.*)/);
                const query = PinSaver.getQueryParameters();
                url = `/v2/galleries/${instrument ? instrument[1] + '/' : ''}${instrument ? instrument[2] : page[1]}/${query.content || ''}?ordinal=${offset}&queues=${query.queues || ''}`;
                break;
        }

        if ( currentBoardType !== 'gallery' && subtree ) {
            url = subtree.url;
        }

        if ( cache[url] ) {
            if ( isFetch && cache[url].offset ) {
                offset = cache[url].offset;
            }
            return Promise.resolve(cache[url]);
        }

        return PinSaver.get(url, {
            "X-NewRelic-ID": xpid,
            "X-BCP": bcp
        })
            .then(data => {
                if ( !subtree && (data.offset || data.ordinal) ) {
                    offset = data.offset;
                }

                if ( !subtree && currentBoardType === 'search' ) {
                    offset += 1;
                    cache[url] = parseSearch(data.html);
                    cache[url].offset = offset;
                } else {
                    cache[url] = data;
                }

                return cache[url];
            });
    }

    function getDataNext(index, _iteration, data) {
        if ( this.aborted ) {
            return;
        }

        const iteration = _iteration + 1;
        const next = index + queue * iteration;
        const endOfList = next === (currentData.length - 1) + queue;

        this.collect(data.view.project.modules || [], endOfList);

        if (typeof currentData[next] === 'undefined') {
            return;
        }

        return this.getData(false, currentData[next])
            .then(getDataNext.bind(this, index, iteration));
    }

    function isAccepted(pin) {
        return !(pin.is_embed || pin.is_text) && pin;
    }

    function getGrid(grid) {
        const save = [];
        grid.components
            .filter(isAccepted)
            .forEach(pin => save.push(pin));
        return save;
    }

    function appendImages(data) {
        let i = 0;
        data
            .filter((pin) => {
                const image = i < 8 && getImage(pin);
                if ( !image ) {
                    return false;
                }
                i++;
                return image;
            })
            .forEach((pin) => {
                this.pushHeadIMG(getImage(pin).url);
            });
    }

    function getImage(pin) {
        let width = 1;
        let height = 1;
        let url;

        switch(currentBoardType) {
            case 'gallery':
                if ( typeof pin.picture === 'undefined' ) {
                    return false;
                }

                const image = pin.picture.sources[0];
                width = image.width;
                height = image.height;
                url = image.src || image.srcset;
                break;
            case 'projects':
            case 'collection':
            case 'appreciated':
            case 'featured':
            case 'galleries':
                const pinData = pin.covers !== undefined ? pin : pin.project;
                url = pinData.covers['404'] || pinData.covers['original'];
                break;
            case 'search':
                url = pin.src;
                break;
        }

        return { width, height, url };
    }

    function getUrl(pin) {
        if ( pin.is_image ) {
            return pin.sizes.original;
        } else if ( pin.is_video ) {
            const id = pin.src.match(/ccv\/(.*)\/embed/);
            if ( id === null || id.length === 0 ) {
                PinSaver.captureException('Error getting video url', pin);
            }
            return `https://adobeprod-a.akamaihd.net/${id[1]}/rend/${id[1]}_720.mp4`;
        }
    }

    function getTitle() {
        return document.title.replace('on Behance', '').trim();
    }

    function parseSearch(html) {
        const document = PinSaver.DOMParser(html);
        return [...document.querySelectorAll('body > div')].map( pin => ({
            url: pin.querySelector('a').href,
            src: pin.querySelector('a > img').getAttribute('srcset').split(',')[1].trim().replace(' 2x', '')
        }));
    }

    function setBCP() {
        if (document.cookie !== '') {
            let e;
            let n;
            const t = 'bcp';
            const i = document.cookie.split(";");
            for (e = 0; e < i.length; e++) {
                n = i[e].trim();
                if (n.substring(0, t.length + 1) === t + "=") {
                    bcp = decodeURIComponent(n.substring(t.length + 1));
                }
            }
        }
    }

})();