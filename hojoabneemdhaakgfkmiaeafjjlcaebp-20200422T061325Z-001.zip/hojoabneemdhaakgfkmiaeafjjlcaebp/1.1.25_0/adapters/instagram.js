'use strict';

var PinSaver = PinSaver || {};
PinSaver.adapters = PinSaver.adapters || {};

(function() {

    let currentBoardType = null;
    let currentBoardId = null;
    let rhx_gis;
    let queryId;
    let queryUserId;
    let queryHomeId;
    let queryTaggedId;
    let userId;

    // todo глобальный cache
    const cache = {};

    PinSaver.adapters['instagram'] = {

        prepareData: function() {
            const scripts = [...document.querySelectorAll('script')];
            const profileScript = scripts.filter((script) => /ProfilePageContainer/.test(script.src));
            const consumerScript = scripts.filter((script) => /ConsumerUICommons/.test(script.src));

            const searchUser = new RegExp(/profilePosts\.byUserId\.get(.*)queryId: ?"(.*)" ?, ?queryParams/);
            const searchFeed = new RegExp(/pagesToPreload(.*)profilePosts(.*)queryId: ?"(.*)" ?(.*)edge_owner_to_timeline_media/);
            const homeFeed = new RegExp(/"\/graphql\/query\/";(.*)"([a-f0-9]{32})"(.*)"([a-f0-9]{32})"(.*)"([a-f0-9]{32})"(.*)feed-cache/);
            let src;


            rhx_gis = document.body.innerHTML.match(/"rhx_gis":"([a-f0-9]{32})"/);
            if ( rhx_gis ) {
                rhx_gis = rhx_gis[1];
            } else {
                PinSaver.log('rhx_gis not found!');
            }

            if ( PinSaver.select('.dialog-404') ) {
                PinSaver.log('404 page');
                return Promise.resolve();
            }

            return PinSaver.get('https://www.instagram.com', {
                "X-Instagram-GIS": CryptoJS.MD5(`${rhx_gis}:${location.pathname}`)
            }, true)
                .then(data => {
                    const user = data.match(/"id":"([0-9]+)",/);
                    if ( user ) {
                        userId = user[1];
                    }

                    if ( profileScript.length && consumerScript.length ) {
                        src = [profileScript[0].src, consumerScript[0].src];
                        return src;
                    }

                    const userData = data.match(/window._sharedData = {(.*)};/g);
                    let authorizedUser;

                    if ( !userData.length ) {
                        return Promise.reject('Cannot find user, aborting!');
                    }

                    try {
                        const parsedData = JSON.parse(userData[0].replace('window._sharedData = ','').replace('};','}'));
                        authorizedUser = parsedData.config.viewer.username;
                    } catch(e) {
                        throw new Error('Error parsing user data, aborting!');
                    }

                    return PinSaver.get(`https://instagram.com/${authorizedUser}/`, {
                        "X-Instagram-GIS": CryptoJS.MD5(`${rhx_gis}:/${authorizedUser}/`)
                    }, true)
                        .then(data => {
                            const profileParts = data.match(/<link (.*)href="(.*)ProfilePageContainer\.js(.*)\.js"(.*)\/>/);
                            const consumerParts = data.match(/<script (.*)src="(.*)ConsumerUICommons\.js(.*)\.js"(.*)><\/script>/);
                            src = [
                                `https://www.instagram.com${profileParts[2]}ProfilePageContainer.js${profileParts[3]}.js`,
                                `https://www.instagram.com${consumerParts[2]}ConsumerCommons.js${consumerParts[3]}.js`
                            ];
                            return src;
                        })
                })
                .then(url => PinSaver.get(url[0], {}, true))
                .then(data => {
                    const matchingUser = data.match(searchUser);
                    if ( matchingUser && matchingUser[2] ) {
                        queryUserId = matchingUser[2];
                    }
                    const matchingFeed = data.match(searchFeed);
                    if ( matchingFeed && matchingFeed[3] ) {
                        queryId = matchingFeed[3];
                    }
                    // TODO not worked for now
                    const matchingTagged = data.match(/taggedPosts\.byUserId\.get(.*): ?[a-z]\.pagination}/)[1].match(/\.pagination},queryId: ?"([a-z0-9]+)", ?queryParams/);
                    if ( matchingTagged && matchingTagged[1] ) {
                        queryTaggedId = matchingTagged[1];
                    }
                })
                .then(() => PinSaver.get(src[1], {}, true))
                .then(data => {
                    const matchingHome = data.match(homeFeed);
                    // TODO not worked for now
                    if ( matchingHome && matchingHome[2] ) {
                        queryHomeId = matchingHome[2];
                    }
                })
                .catch(e => {
                    PinSaver.log(e);
                });
                // TODO explore! view-source:https://www.instagram.com/explore/
                // DiscoverMediaPageContainer
        },

        getData: function(...args) {
            return getData.apply(undefined, [this.currentBookmark, ...args])
        },

        setData: function() {
            const preType = getTypes();
            let text;
            let badge;

            if ( !preType ) {
                this.hideAction();
                this.setTitle('There is no active boards to save pins');
                this.setBadge('...');
                return;
            }

            currentBoardType = preType.resource;

            this.getData().then((data) => {
                const currentData = data.data || data.graphql;
                const { pinNum, currentBoardName, currentPins, currentBookmark } = setData(currentData);

                text = PinSaver.getNumber(pinNum) + ' pins found';
                badge = PinSaver.calcNum(PinSaver.getNumber(pinNum || 0));

                this.pinNum = pinNum;
                this.currentBookmark = currentBookmark;
                this.currentBoardName = currentBoardName;
                this.currentPins = currentPins;

                if ( !preType.num ) {
                    this.pinNum = -1;
                    text = "Can't detect fixed pin number";
                    badge = '∞';
                }

                this.showAction();
                this.updateUI(preType.text);
                this.setTitle(text);
                this.setBadge(badge);

                let media;
                if ( currentBoardType === 'user' ) {
                    media = currentData.user.edge_owner_to_timeline_media.edges;
                } else if ( currentBoardType === 'tags' ) {
                    media = currentData.hashtag.edge_hashtag_to_media.edges;
                } else if ( currentBoardType === 'saved' ) {
                    media = currentData.user.edge_saved_media.edges;
                } else if ( currentBoardType === 'tagged' ) {
                    media = currentData.user.edge_user_to_photos_of_you.edges;
                }

                appendImages.call(this, media);
            });
        },

        fetchData: function(data) {
            if ( this.aborted ) {
                return;
            }

            let type;
            let storage = currentBoardType !== 'tags' ? (data.data || data.graphql).user : data.graphql.hashtag;

            //todo отдавать из setData
            if ( currentBoardType === 'home' ) {
                type = 'edge_web_feed_timeline';
            } else if ( currentBoardType === 'user' ) {
                type = 'edge_owner_to_timeline_media';
            } else if ( currentBoardType === 'explore' ) {
                type = 'edge_web_discover_media';
            } else if ( currentBoardType === 'tags' ) {
                type = 'edge_hashtag_to_media';
            } else if ( currentBoardType === 'saved' ) {
                type = 'edge_saved_media';
            } else if ( currentBoardType === 'tagged' ) {
                type = 'edge_user_to_photos_of_you';
            }

            const pins = storage[type].edges;
            const bookmarks = storage[type].page_info;

            const noData = pins.length === 0;
            const endOfList = !bookmarks.has_next_page;

            this.currentBookmark = endOfList ? null : bookmarks.end_cursor;

            if ( !noData ) {
                // todo переделать на промисы, сделать вызов из pinsaver с учётом постепенной загрузки
                this.collect(pins, endOfList);
            }

            if ( endOfList ) {
                return;
            }

            this.fetch();
        },

        collectData: function(pins) {
            const save = [];
            pins.some((pin) => {
                const original = pin.node.display_url;
                const resources = pin.node.display_resources;
                const url = (!resources || original === resources[resources.length - 1].src) ? original : resources[resources.length-1];
                const thumbResources = pin.node.thumbnail_resources;
                const checked = this.checkCollection();
                if ( checked ) {
                    save.push({
                        id: pin.node.id,
                        url,
                        // ЗАГРУЖАТЬ ВИДЕО РУКАМИ С СИГНАТУРОЙ
                        //!pin.node.is_video ? pin.node.display_url : pin.node.display_url.replace('.jpg', '.mp4'),
                        description: pin.node.edge_media_to_caption && pin.node.edge_media_to_caption.edges.length && pin.node.edge_media_to_caption.edges[0].node.text,
                        replace: thumbResources && thumbResources[thumbResources.length - 1].src

                    });
                }
                return !checked;
            });

            return save;
        },

        resetData: function(softReset) {
            if ( !softReset ) {
                this.currentPins = [];
                currentBoardId = null;
            }
        }
    };

    function getTypes() {
        const loc = location.href;
        const path = location.pathname;

        const board = loc.match(/instagram\.com\/(.+)/);
        const saved = path.match(/\/(.+)\/saved/);
        const tagged = path.match(/\/(.+)\/tagged/);
        const search = loc.match(/instagram\.com\/explore\/tags\/(.+)/);

        // main page
        if ( path === "" || path === "/" ) {
            return false;

        } else if (
            loc.match(/instagram\.com\/(.+)\/(followers|following)/) ||
            loc.match(/instagram\.com\/(oauth|stories|p|accounts|terms|integrity|about|media|emails|create)\//) ||
            loc.match(/instagram\.com\/web\/likes/) ||
            loc.match(/instagram\.com\/accounts\/password/) ||
            loc.match(/(l|help|graph|business)\.instagram\.com/)
        ) {
            PinSaver.log('Excluded page, stopping');
            return false;
        } else if ( loc.match(/instagram\.com\/explore\/tags(.+)\/*/) ) {
            return {
                text: 'Instagram-tags__' + decodeURIComponent(search[1]).__pindown_stripSlash(),
                num: true,
                resource: 'tags'
            };

        } else if ( loc.match(/instagram\.com\/explore/) ) {
            // TODO !!!
            return false;
            return {
                text: 'Instagram-explore__' + Date.now(),
                num: false,
                resource: 'explore'
            };
        } else if ( saved ) {
            return {
                text: 'Instagram-saved__' + decodeURIComponent(saved[1]).__pindown_stripSlash(),
                num: true,
                resource: 'saved'
            };
        } else if ( tagged ) {
            return {
                text: 'Instagram-tagged__' + decodeURIComponent(tagged[1]).__pindown_stripSlash(),
                num: true,
                resource: 'tagged'
            };
        } else if ( board ) {
            return {
                text: decodeURIComponent(board[1]).__pindown_stripSlash(),
                num: true,
                resource: 'user'
            };
        }

        return false;

    }

    function getData(currentBookmark, isFeed) {
        let url;
        let gis = CryptoJS.MD5(`${rhx_gis}:${location.pathname}`);
        let qId = queryId;

        const isTagged = currentBoardType === 'tagged';

        const fetchObj = {
            "first": isFeed ? 200 : 20
        };

        if ( currentBoardType === 'user' ) {
            if ( isFeed ) {
                fetchObj.id = currentBoardId;
            } else {
                url = `${location.pathname}?__a=1`;
                if ( location.pathname[location.pathname.length-1] !== '/' ) {
                    gis = CryptoJS.MD5(`${rhx_gis}:${location.pathname}/`);
                }
            }

        } else if ( currentBoardType === 'tags' ) {
            url = `${location.pathname}?__a=1`;
            fetchObj.tag_name = location.pathname.match(/tags\/(.*)\//)[1];
            fetchObj.first = 2;

        } else if ( currentBoardType === 'home' ) {
            qId = queryHomeId;
            fetchObj.fetch_media_item_count = isFeed ? 200 : 20;
        } else if ( currentBoardType === 'saved' ) {
            url = `${location.pathname}?__a=1`;
        } else if ( isTagged ) {
            qId = queryTaggedId;
            fetchObj.first = 12;
        }

        if ( currentBookmark ) {
            fetchObj.after = currentBookmark;
        }

        if ( !url ) {
            url = `https://www.instagram.com/graphql/query/?query_hash=${qId}&variables=${encodeURIComponent(JSON.stringify(fetchObj))}`;
        }

        if ( cache[url] ) {
            return Promise.resolve(cache[url]);
        }

        if ( isTagged ) {
            const userURL = `/${location.pathname.split('/')[1]}/?__a=1`;
            return (
                ( cache[userURL] && Promise.resolve(cache[userURL]) )
                ||
                PinSaver
                    .get(userURL, {
                        "X-Instagram-GIS": gis
                    })
                    .then( userData => (cache[userURL] = userData) && userData)
            )
                .then( userData => {
                    fetchObj.id = userData.graphql.user.id;
                    url = `https://www.instagram.com/graphql/query/?query_hash=${qId}&variables=${encodeURIComponent(JSON.stringify(fetchObj))}`;
                    return (
                        ( cache[url] && Promise.resolve(cache[url]) )
                        ||
                        PinSaver
                            .get(url, {
                                "X-Instagram-GIS": gis
                            })
                            .then( data => (cache[url] = data) && data)
                    );
            });
        }

        return PinSaver.get(url, {
            "X-Instagram-GIS": gis
        }).then( data => (cache[url] = data) && data);
    }

    function setData(data) {
        let pinNum = 0;
        let currentBoardName = '';
        let currentBookmark = false;
        let currentPins = [];

        if ( currentBoardType === 'tags' ) {
            pinNum = data.hashtag.edge_hashtag_to_media.count;
            currentBoardName = data.hashtag.name;
            currentPins = data.hashtag.edge_hashtag_to_media.edges;

            if ( data.hashtag.edge_hashtag_to_media.page_info.has_next_page ) {
                currentBookmark = data.hashtag.edge_hashtag_to_media.page_info.end_cursor;
            }

        } else if ( currentBoardType === 'user' ) {
            pinNum = data.user.edge_owner_to_timeline_media.count;
            currentBoardName = data.user.username;
            currentBoardId = data.user.id;
            currentPins = data.user.edge_owner_to_timeline_media.edges;

            if ( data.user.edge_owner_to_timeline_media.page_info.has_next_page ) {
                currentBookmark = data.user.edge_owner_to_timeline_media.page_info.end_cursor;
            }
        } else if ( currentBoardType === 'saved' ) {
            pinNum = data.user.edge_saved_media.count;
            currentBoardName = data.user.username + ' saved';
            currentPins = data.user.edge_saved_media.edges;

            if ( data.user.edge_saved_media.page_info.has_next_page ) {
                currentBookmark = data.user.edge_saved_media.page_info.end_cursor;
            }
        } else if ( currentBoardType === 'tagged' ) {
            pinNum = data.user.edge_user_to_photos_of_you.count;
            currentPins = data.user.edge_user_to_photos_of_you.edges;

            if ( data.user.edge_user_to_photos_of_you.page_info.has_next_page ) {
                currentBookmark = data.user.edge_user_to_photos_of_you.page_info.end_cursor;
            }
        } else {
            return {};
        }

        return { pinNum, currentBoardName, currentPins, currentBookmark };
    }

    function appendImages(data) {
        let i = 0;
        data
            .filter(() => ++i < 8 )
            .forEach((pin) => {
                this.pushHeadIMG(pin.node.display_url);
            });
    }

})();