'use strict';

var PinSaver = PinSaver || {};
PinSaver.adapters = PinSaver.adapters || {};

(function() {

    const api_key = 'GSgWCc96GxL3x2OlEtMUE56b8gjbFHSV5wf8Zm8Enr1kNcjt3U';
    const cache = {};
    let currentBookmark = 0;

    PinSaver.adapters['tumblr'] = {

        // todo кэшироваине повторных запросов
        getData: function() {
            const url = `https://api.tumblr.com/v2/blog/${location.host}/posts/photo?api_key=${api_key}&offset=${currentBookmark}&reblog_info=true`;

            if ( typeof cache[url] !== 'undefined' ) {
                return Promise.resolve(cache[url]);
            }

            return this.getCORSData(
                url,
                // headers
                {},
                // object data to return
                ['response'],
                false
            ).then(data => {
                if ( data.hasError ) {
                    this.hideAction();
                    const error = JSON.parse(data.response);
                    if ( error.meta.status === 404 ) {
                        return { response: { posts: [] } };
                    }
                    throw new Error('Error parsing Tumblr data');
                }

                cache[url] = data.response;
                return cache[url];
            });
        },

        setData: function() {
            // TODO https://www.tumblr.com/blog/learnfashiontailoring
            if (
                location.href.match(/assets\.tumblr\.com/) ||
                location.href.match(/tumblr\.com\/(dashboard|reblog|likes|search|privacy)/) ||
                location.href.match(/www\.tumblr\.com\//)
            ) {
                this.hideAction();
                return;
            }

            this.getData()
                .then((data) => {
                    this.pinNum = data.total_posts;
                    this.currentPins = data.posts;
                    currentBookmark = 20;

                    const text = 'More then ' + PinSaver.getNumber(this.pinNum) + ' pins found';
                    const badge = PinSaver.getNumber(this.pinNum || 0) + '+';

                    this.showAction();
                    this.updateUI(location.host.match('(.*)\.tumblr\.com')[1]);
                    this.setTitle(text);
                    this.setBadge(badge);

                    appendImages.call(this, data.posts);
                });
        },

        fetchData: function(data) {
            if ( this.aborted ) {
                return;
            }

            const endOfList = data.posts.length < 20;

            currentBookmark = endOfList ? null : currentBookmark + data.posts.length;
            // todo переделать на промисы, сделать вызов из pinsaver с учётом постепенной загрузки
            this.collect(data.posts, endOfList);

            if ( endOfList ) {
                return;
            }

            this.fetch();
        },

        collectData: function(pins) {
            const save = [];
            pins.some((pin) => {
                const checked = this.checkCollection();
                if ( typeof pin.photos !== 'undefined' && checked ) {
                    pin.photos.forEach((photo, i) => {
                        save.push({
                            id: `${pin.id}-${i}`,
                            url: photo.original_size.url,
                            description: photo.caption,
                            description_link: pin.post_url
                        });
                    });
                }
                return !checked;
            });
            return save;
        },

        resetData: function() {
            currentBookmark = 0;
        }
    };

    function appendImages(data) {
        data
            .reduce((current, next) => {
                const images = [];
                if ( typeof next.photos === 'undefined' ) {
                    return current;
                }

                next.photos.forEach((photo) => {
                    const thumb = photo.alt_sizes[1];
                    // todo 8 - в глобальные переменные
                    if ( thumb.width * 0.7 < thumb.height && (current.length + images.length) < 8 ) {
                        images.push(thumb);
                    }
                });
                return current.concat(images);
            }, [])
            .forEach((pin) => {
                this.pushHeadIMG(pin.url);
            });
    }

})();