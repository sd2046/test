'use strict';

var PinSaver = PinSaver || {};
PinSaver.adapters = PinSaver.adapters || {};

(function() {

    let currentBoardId = null;
    let currentBoardType = null;
    let currentBoardOptions = null;
    let currentBoardHasResource = false;
    let currentBookmark = false;
    const resolver = Promise.resolve({resource_response: { data: {}}});

    PinSaver.adapters['pinterest'] = {

        getData: function(...args) {
            return getData.apply(undefined, [this.currentBoardName, ...args])
        },

        setData: function () {
            const preType = getTypes(this.pinNum);

            if (!preType) {
                this.hideAction();
                this.setTitle('There is no active boards to save pins');
                this.setBadge('...');
                return;
            }

            currentBoardType = preType.resource;
            currentBoardOptions = preType.options;
            currentBoardHasResource = preType.subresource;

            this.getData().then((data) => {
                const { currentBoardName, pinNum } = setData(data.resource_response.data);
                const type = getTypes(pinNum, currentBoardName);

                if (!type) {
                    return;
                }

                let text = PinSaver.getNumber(pinNum) + ' pins found';
                let badge = PinSaver.calcNum(pinNum || 0);

                this.currentBoardName = type.text;
                this.pinNum = pinNum;

                if (!type.num) {
                    this.pinNum = -1;
                    text = "Can't detect fixed pin number";
                    badge = '∞';
                }

                this.showAction();
                this.updateUI(type.text);
                this.setTitle(text);
                this.setBadge(badge);

                appendImages.call(this);
            });
        },

        fetchData(data) {
            if ( this.aborted ) {
                return;
            }

            const res = (data.resource_response.data.length && data.resource_response.data) ||
                data.resource_response.data.results ||
                data.resource_response.data.interest_feed ||
                data.resource_response.data.result_pins;

            const bookmarks = data.resource.options.bookmarks || data.resource_response.data.bookmarks;
            const noBookmarks = !bookmarks || data.resource_response.error;
            const noData = !res || (res && res.length === 0);
            const endOfList = bookmarks[0] === "-end-" || noData;

            currentBookmark = (noBookmarks || endOfList) ? null : data.resource.options.bookmarks;

            // todo переделать на промисы, сделать вызов из pinsaver с учётом постепенной загрузки
            this.collect(res || [], endOfList);

            if ( endOfList ) {
                return;
            }

            this.fetch();
        },

        collectData(pins) {
            const save = [];
            pins.some((pin) => {
                const checked = this.checkCollection();
                if ( checked && pin.type === 'pin' ) {
                    const image = getImage(pin);
                    save.push({
                        id: pin.id,
                        url: image.url,
                        description: pin.description || "",
                        description_html: pin.description_html,
                        description_link: pin.link,
                        replace: pin.images['736x'].url
                    });
                } else {
                    PinSaver.log('Not a pin', pin);
                }
                return !checked;
            });

            return save;
        },

        resetData(softReset) {
            if ( !softReset ) {
                currentBoardId = null;
                currentBoardHasResource = false;
            }
            currentBookmark = false;
        }
    };

    function getTypes(pinNum, currentBoardName) {
        const loc = location.href;
        const path = location.pathname;

        let board = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/(.+)/);
        let section = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/(.+)\/(?!\?)(.+)/)
        let pins = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/pins\/?$/);

        const domain = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/source\/(.+)/);
        const topics = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/topics\/(.+)/);
        // language not de -> discover-> https://www.pinterest.de/discover/topics/4851728436240074747/ -> https://www.pinterest.de/discover/article/BEVAm...?topic=4851728436240074747
        const article = loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/discover\/article\/(.*)\/?\?topic=(.*)/);

        // main page
        if ( path === "" || path === "/" ) {
            return {
                text: 'Pinterest-dashboard-' + Date.now(),
                num: false,
                resource: 'UserHome'
            };

            // pages without pins
        } else if (
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/(followers|_followers|following|_following|boards|tried|topics|overview|login)\/?$/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(news_hub|settings|oauth)\//) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/pin\/(.*)\/activity/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/categories\/*$/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/following\/people$/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/search\/(boards|users)/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/pin\/(create|find)/) ||
            loc.match(/(developers|business|policy|about|help|newsroom|ads)\.pinterest/) ||
            loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.*)\/connect\/facebook\/?$/)

        ) {
            PinSaver.log('Excluded page, stopping');
            return false;

            // search pages
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/search\/(pins|my_pins|buyable_pins)/) ) {
            const scope = location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/search\/(pins|my_pins|buyable_pins)/)[2];
            return {
                text: 'search__' +
                scope +
                '__' +
                decodeURIComponent(location.href.split('q=')[1].split('&')[0]),
                num: false,
                resource: 'BaseSearch',
                options: {
                    scope
                }
            };

            // own pins
        } else if ( pins ) {
            return {
                text: pins[2] + '__pins',
                num: pinNum,
                resource: 'User'
            };

            // visual search pins
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/pin\/(.+)\/visual-search/) ) {
            return {
                text: "Visual search for pin " + location.pathname.match(/pin\/(.+)\/visual-search/)[1],
                num: false,
                resource: 'VisualLiveSearchResource'
            };

            // search by source/cat
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/pin\/(.+)/) ) {
            return {
                text: "Related to pin " + location.pathname.match(/\/pin\/(.+)\/?/)[1].__pindown_stripSlash(),
                num: false,
                resource: 'Pin'
            };

            // search by source/cat
        } else if ( domain ) {
            return {
                text: domain[3],
                num: false,
                resource: 'Domain'
            };

            // following
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/following\/*$/) ) {
            return {
                text: 'Following-' + Date.now(),
                num: false,
                resource: 'Following'
            };

        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/discover\/topics/) ) {
            return {
                text: 'Topic ' + (currentBoardName && currentBoardName.name),
                num: false,
                resource: 'Category'
            };

        } else if ( article ) {
            return {
                text: 'Article ' + currentBoardName,
                num: false,
                resource: 'ExploreTabStory',
                options: {
                    id: String(article[2]).__pindown_stripSlash(),
                    topicId: article[3]
                }
            };

        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/categories\/()/) ) {
            return {
                text: 'Category ' + ( currentBoardName && currentBoardName.name ),
                num: false,
                resource: 'Category',
                subresource: true
            };

        } else if ( topics ) {
            const id = location.pathname.match(/ID:(.*)\/?/);
            return {
                text: !id ? topics[2] : id[1],
                num: false,
                resource: 'Topic'
            };

            // section boards
        } else if ( section ) {
            // blank section board
            if ( currentBoardId && !pinNum) {
                return false;
            }
            return {
                text: currentBoardName,
                num: pinNum,
                resource: 'BoardSection'
            };

            // explore
            // anonymous -> any pin -> links around
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/explore\/(.*)/) ) {
            // TODO аюзать InterestResource
            let state = window.__INITIAL_STATE__;
            if ( !state ) {
                state = JSON.parse(document.getElementById('initial-state').innerText);
            }
            const interest = state.resources.data.InterestResource;
            const data = interest[Object.keys(interest)[0]].data;
            return {
                text: 'Explore ' + (data.name || data.query),
                num: false,
                resource: data.id ? 'ReactKLPResource' : 'Search',
                options: {
                    id: data.id,
                    name: data.name || data.query
                }
            };

            // activities https://tr.pinterest.com/ailedemutluluk/_activities/
        } else if ( loc.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/(activities|_activities)/)  ) {
            return {
                text: 'Activities ' + currentBoardName,
                num: false,
                resource: 'UserDiscoveredPins'
            };
        } else if ( board ) {
            // blank board
            if (currentBoardId && !pinNum) {
                return false;
            }
            return {
                text: currentBoardName,
                num: pinNum,
                resource: 'Board'
            };
        }

    }

    // todo кэшироваине повторных запросов
    function getData(currentBoardName, isFeed, short) {
        const isHome = currentBoardType === 'UserHome';
        const isBoard = currentBoardType === 'Board';
        const isBoardSection = currentBoardType === 'BoardSection';
        const isFollowing = currentBoardType === 'Following';

        const fetchObj = {
            options: {},
            context: {}
        };

        let source_url = encodeURIComponent(location.pathname);
        let type = 'Resource';
        let pre = '';
        let path;
        let useBoardType = true;

        if ( isFeed ) {
            type = 'FeedResource';
        }

        switch( currentBoardType ) {
            case 'Board':
                if (isFeed) {
                    fetchObj.options = {
                        "board_id": currentBoardId,
                        "board_url": location.pathname,
                        "field_set_key": "react_grid_pin",
                        "filter_section_pins": true,
                        "layout": "default",
                        "page_size": short ? 20 : 250,
                        "redux_normalize_feed": true
                    };
                } else {
                    path = location.pathname.split('/');
                    fetchObj.options = {
                        "username": decodeURIComponent(path[1]),
                        "slug": decodeURIComponent(path[2]),
                        "field_set_key": "detailed",
                        "main_module_name": "BoardPage"
                    };
                }
                break;

            case 'BoardSection':
                if ( isFeed ) {
                    type = 'PinsResource';
                    fetchObj.options = {
                        "field_set_key": "react_grid_pin",
                        "is_own_profile_pins": true,
                        "page_size": short ? 20 : 250,
                        "redux_normalize_feed": true,
                        "section_id": currentBoardId
                    };
                } else {
                    path = location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/(.+)\/(.+)/);
                    fetchObj.options = {
                        "board_slug": decodeURIComponent(path[3]),
                        "section_slug": decodeURIComponent(path[4].__pindown_stripSlash()),
                        "username": decodeURIComponent(path[2])
                    };
                }
                break;

            case 'Pin':
                path = location.pathname.split('/');
                if ( isFeed ) {
                    fetchObj.options = {
                        "field_set_key": "base_grid",
                        "pin": path[2],
                        "prepend": false,
                        "search_query": "",
                        "context_pin_ids": [],
                        "source": "deep_linking",
                        "top_level_source": "deep_linking",
                        "top_level_source_depth": 1
                    };
                    pre = 'Related';
                } else {
                    fetchObj.options = {
                        "field_set_key": "detailed",
                        "id": path[2],
                        "pure_react": true
                    };
                }
                break;

            case 'VisualLiveSearchResource':
                path = location.pathname.split('/');
                if ( isFeed ) {
                    type = '';
                    fetchObj.options = {
                        "pin_id": path[2],
                        "image_signature": currentBoardOptions.image_signature,
                        "crop": currentBoardOptions.visual_objects,
                        "text_filters": [],
                        "keep_duplicates": false
                    };
                } else {
                    pre = 'Pin';
                    useBoardType = false;
                    fetchObj.options = {
                        "field_set_key": "detailed",
                        "id": path[2],
                        "fetch_visual_search_objects": true
                    };
                }
                break;

            case 'UserHome':
                if ( isFeed ) {
                    type = 'feedResource';
                    fetchObj.options = {
                        "field_set_key": "hf_grid",
                        "in_nux": false,
                        "is_react": true,
                        "prependPartner": false,
                        "prependUserNews": false,
                        "repeatRequestBookmark": "",
                        "static_feed": false
                    };
                } else {
                    return resolver;
                }
                break;

            case 'BaseSearch':
                if ( isFeed ) {
                    source_url = encodeURIComponent(location.pathname + location.search);
                    const search = PinSaver.getQueryParameters();
                    type = 'Resource';
                    fetchObj.options = {
                        "auto_correction_disabled": false,
                        "corpus": null,
                        "customized_rerank_type": null,
                        "filters": null,
                        "page_size": null,
                        "query": decodeURIComponent(search.q),
                        "query_pin_sigs": null,
                        "redux_normalize_feed": false,
                        "rs": "rs",
                        "scope": currentBoardOptions.scope,
                        "article": null
                    };
                } else {
                    return resolver;
                }
                break;

            case 'Search':
                if ( isFeed ) {
                    type = 'Resource';
                    fetchObj.options = {
                        "auth_lp_type": "klp",
                        "query": currentBoardOptions.name
                    };
                } else {
                    return resolver;
                }
                break;

            case 'User':
                const user = decodeURIComponent(location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/(.+)\/pins\/?$/)[2]);
                if ( isFeed ) {
                    type = 'PinsResource';
                    fetchObj.options = {
                        "is_own_profile_pins": true,
                        "username": user,
                        "field_set_key": "grid_item",
                        "pin_filter": null
                    };
                } else {
                    fetchObj.options = {
                        "is_own_profile_pins": true,
                        "username": user,
                        "field_set_key": "grid_item",
                        "pin_filter": null
                    };
                }
                break;

            case 'Domain':
                if ( isFeed ) {
                    fetchObj.options = {
                        "domain": decodeURIComponent(location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/source\/(.+)\//)[2])
                    };
                } else {
                    return resolver;
                }
                break;

            case 'Category':
                if ( isFeed ) {
                    if ( !currentBoardHasResource ) {
                        fetchObj.options = {
                            "is_category_feed": true,
                            "feed": currentBoardName.category_key
                        };
                    } else {
                        fetchObj.options = {
                            "is_category": true,
                            "feed": currentBoardName.key
                        };
                    }
                } else {
                    if ( !currentBoardHasResource ) {
                        pre = 'ExploreSections';
                        useBoardType = false;
                        fetchObj.options = {
                            "aux_fields": {},
                            "offset": 180
                        };
                    } else {
                        fetchObj.options = {
                            "category": decodeURIComponent(location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/categories\/(.+)/)[2].__pindown_stripSlash())
                        };
                    }
                }
                break;

            case 'Topic':
                path = location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/topics\/(.+)\//);
                const interest = decodeURIComponent(path[2]);
                if ( isFeed ) {
                    if ( !currentBoardHasResource ) {
                        fetchObj.options = {
                            interest,
                            "add_vase": true,
                            "interest_name": currentBoardName,
                            "pins_only": true
                        };
                    } else {
                        useBoardType = false;
                        type = 'BaseSearchResource';
                        fetchObj.options = {
                            "query": currentBoardHasResource,
                            "scope": "pins"
                        };
                    }
                } else {
                    fetchObj.options = {
                        interest,
                        "main_module_name": "TopicFeedPage"
                    };
                }
                break;

            case 'Following':
                if ( isFeed ) {
                    fetchObj.options = {};
                } else {
                    return resolver;
                }
                break;

            case 'ExploreTabStory':
                source_url = encodeURIComponent(location.pathname + location.search);
                if ( isFeed ) {
                    useBoardType = false;
                    pre = 'ExploreTabBlock';
                    fetchObj.options = {
                        "block_id": currentBoardOptions.blockId,
                        "offset": 180,
                        "prepend": false
                    };
                    if ( !currentBoardOptions.fields ) {
                        type = 'Board';
                        fetchObj.options.aux_fields = {};
                    } else {
                        type = 'Pin';
                        fetchObj.options.aux_fields = {
                            "topic": currentBoardOptions.fields.topic,
                            "category": currentBoardOptions.fields.category,
                            "query": currentBoardOptions.fields.query
                        };
                    }
                    type += 'Resource';
                } else {
                    fetchObj.options = {
                        aux_fields: {},
                        offset: 180,
                        story_id: currentBoardOptions.id
                    };
                }
                break;

            case 'ReactKLPResource':
                if ( isFeed ) {
                    type = '';
                    fetchObj.options = {
                        "interest_id": currentBoardOptions.id,
                        "i18n_interest_id": currentBoardOptions.id,
                        "interest_name": currentBoardOptions.name,
                        "is_klp_term": true,
                        "check_is_open": true,
                        "is_best_of_page": false,
                        "no_gift_wrap": null
                    };
                } else {
                    return resolver;
                }
                break;

            case 'UserDiscoveredPins':
                if ( isFeed ) {
                    type = 'Resource';
                    fetchObj.options = {
                        "exclude_add_pin_rep": true,
                        "username": location.pathname.split('/')[1],
                    };
                } else {
                    return resolver;
                }
        }

        if ( currentBookmark ) {
            fetchObj.options.bookmarks = currentBookmark;
        }

        const url = `https://${location.host}/resource/${pre}${(useBoardType && currentBoardType) || ''}${type}/get/?source_url=${source_url}&data=${encodeURIComponent(JSON.stringify(fetchObj))}&_=${new Date().getTime()}`;

        return PinSaver.get(url, {
            "Accept": 'application/json, text/javascript, */*; q=0.01',
            'X-Pinterest-AppState': !(isHome || isBoardSection || isFollowing || isBoard) ? 'active' : 'background'
        });
    }

    function setData(data) {
        let pinNum = 0;
        let currentBoardName = '';

        if ( ['Pin', 'UserHome', 'Topic', 'Category', 'ExploreTabStory'].indexOf(currentBoardType) > -1 ) {
            pinNum = -1;
        }

        if ( ['Board', 'BoardSection', 'User'].indexOf(currentBoardType) > -1 ) {
            currentBoardId = data.id;
            pinNum = data.pin_count;
            currentBoardName = data.name || data.title;

        } else if ( ['Pin', 'UserHome', 'VisualLiveSearchResource'].indexOf(currentBoardType) > -1 ) {
            currentBoardId = data.id;
            currentBoardName = data.description || data.closeup_user_note || data.name;

            if ( currentBoardType === 'VisualLiveSearchResource' ) {
                const visual_objects = data.visual_objects[0];
                delete visual_objects.detection;
                delete visual_objects.score;
                currentBoardOptions = {
                    image_signature: data.image_signature,
                    visual_objects
                }
            }

        } else if ( currentBoardType === 'Topic' ) {
            currentBoardId = data.id;
            if ( data.is_interest ) {
                currentBoardName = data.name;
            } else {
                currentBoardName = data.name.replace(/id:/i,'');
                currentBoardHasResource = data.key;
            }

        } else if ( currentBoardType === 'Category' ) {
            if ( !currentBoardHasResource ) {
                // массив значений с категориями
                currentBoardName = data.filter(filterCurrentExploreSection)[0];
            } else {
                currentBoardName = {
                    key: data.key,
                    name: data.name,
                    toString: () => data.name
                };
            }

        } else if ( currentBoardType === 'ExploreTabStory' ) {
            currentBoardName = data.title.format;
            currentBoardOptions.blockId = data.objects[0].id
            if ( !data.show_cover ) {
                currentBoardOptions.fields = data.logging_aux_data.aux_fields;
            }
        }

        return { currentBoardName, pinNum };
    }

    function filterCurrentExploreSection(section) {
        return location.href.match(/pinterest\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?\/discover\/topics\/(.+)\//)[2] == section.id;
    }

    function appendImages() {
        getData(this.currentBoardName, true, true)
            .then(data => {
                const res = (data.resource_response.data.length && data.resource_response.data) ||
                    data.resource_response.data.results ||
                    data.resource_response.data.interest_feed ||
                    data.resource_response.data.result_pins;
                if ( !res ) {
                    PinSaver.log('No resource data!');
                    return;
                }

                let i = 0;
                res
                    .filter((pin) => {
                        i++;
                        const image = pin.type === 'pin' && i < 8 && getImage(pin, true);
                        return image.width * 0.7 < image.height;
                    })
                    .forEach((pin) => {
                        this.pushHeadIMG(getImage(pin, true).url);
                    });
            });
    }

    function getImage(pin, useThumb) {
        if ( pin.images ) {
            return useThumb ? pin.images['474x'] : pin.images.orig;
        }

        return {
            width: pin.image_large_size_pixels.width,
            height: pin.image_large_size_pixels.height,
            url: pin.image_large_url
        };
    }

})();